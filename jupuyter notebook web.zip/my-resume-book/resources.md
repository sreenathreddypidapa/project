# Resources

## My Work With Links

- [MLFlow Experiments](https://dagshub.com/sreenathreddy6633/price-detection.mlflow)  
- [DagsHub Project](https://dagshub.com/sreenathreddy6633/price-detection)  
- [Docker Hub Container](https://hub.docker.com/repository/docker/sreenathreddypidapa/fastapi)  
- [Deployed Model](https://dashboard.render.com/web/srv-ctilofbtq21c73dr89pg)  
- [Streamlit App](https://fastapi-latest-wrpd.onrender.com)  
- [Final Deployed Model](https://project-qpvpf4g2rkndn5ebp6tjki.streamlit.app)  
- [GitHub](https://github.com/sreenathreddypidapa/project)
- [Video Recordings](https://drive.google.com/file/d/1JAvD_uPK4Jm6a_s88fxCqK4o3Apu_l57/view)
  
